<?php
/*
Plugin Name: qiniu_imageslim
Plugin URI: https://www.xikuang.ren/
Description: 使用七牛imageslim命令为图片瘦身减少流量，提升网页打开速度。图片必须是七牛空间的jpg\jpeg\png格式图片。
Version: 0.1
Author:西狂
Author URI: https://www.xikuang.ren/
License: free
Text Domain: https://www.xikuang.ren/
*/
function QiNiuShouShen(){
    function Rewrite_URI($htmlSS){
        /* 七牛图片瘦身目前仅支持jpg|png|jpeg,前面是引用七牛图片的自定义地址 */
        $patternSS ='/src=\"http:\/\/zy\.xikuang\.ren\/([^"\']*?)\.(jpg|png|jpeg)/i';
        /* 自动添加七牛图片瘦身命令?imageslim */
        $replacementSS = 'src="http://zy.xikuang.ren/$1.$2?imageslim';
    $htmlSS = preg_replace($patternSS, $replacementSS,$htmlSS);
    return $htmlSS;
    }
    if(!is_admin()){
        ob_start("Rewrite_URI");
    }
}
add_action('init', 'QiNiuShouShen');
?>
